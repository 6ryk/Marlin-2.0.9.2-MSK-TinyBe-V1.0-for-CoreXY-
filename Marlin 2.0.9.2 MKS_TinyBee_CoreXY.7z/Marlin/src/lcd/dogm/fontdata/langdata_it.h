/**
 * Generated automatically by buildroot/share/fonts/uxggenpages.sh
 * Contents will be REPLACED by future processing!
 * Use genallfont.sh to generate font data for updated languages.
 */
#pragma once

#include "langdata.h"

static const uxg_fontinfo_t g_fontinfo_it[] PROGMEM = {};
